# KahootBot

KahootBot is a Discord bot to spam Kahoot games between 200-400 bots.

## Installation

You need NPM and Node in order to run this bot. You can download both from [NodeJS](https://nodejs.org/en/download/) website

```bash
npm install
```

```bash
node .
```


## Configuration

Change the `.env.example` file to `.env` and gather your token from [Discord Developers](https://discord.com/developers/applications). 
